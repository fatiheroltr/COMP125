﻿/*JavaScript 6th Edition
      Chapter 1
      Chapter case

      Tinley Xeriscapes
      Plants web page
      Author: Patrick
      Date: May 27,2020

      Filename: plants.js
*/
var blanket="images/blanket.jpg";
var bluestem="images/bluestem.jpg";
var rugosa="images/rugosa.jpg";
