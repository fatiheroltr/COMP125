vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Jan 2015 13:45:24 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|Joanne-sEnvy\\Joanne Filotti
vti_modifiedby:SR|Joanne-sEnvy\\Joanne Filotti
vti_timecreated:TR|12 Jan 2015 13:45:24 -0000
vti_cacheddtm:TX|12 Jan 2015 13:45:24 -0000
vti_filesize:IR|2578
vti_backlinkinfo:VX|COMP125/Week02/Examples/Chapter/estimate.htm
